# Flatland
A pancaked robot running around on flatland.
This package contains a robot simulator built using pybox2d (https://github.com/pybox2d/pybox2d) and is used in the course ECE 4960/5960, Cornell University (2022).

Ref: https://github.com/pybox2d/pybox2d