This folder contains a stripped down version of the pygame backend used in pybox2d (https://github.com/pybox2d/pybox2d).
1. It prevents mouse interactions with the simulated objects
2. It is compatable with ipykernel

Ref: https://github.com/pybox2d/pybox2d